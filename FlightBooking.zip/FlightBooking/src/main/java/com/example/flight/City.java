package com.example.flight;

public enum City {
Delhi,
Mumbai,
Chennai,
Kolkata,
Indore,
}