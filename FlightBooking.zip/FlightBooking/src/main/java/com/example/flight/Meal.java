package com.example.flight;

public enum Meal {
None,
NonVeg,
Veg
}