package com.example.flight;

public enum Airline {
	JetAirways,
	AirIndia,
	Indigo
}